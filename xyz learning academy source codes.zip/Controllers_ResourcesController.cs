using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

public class ResourcesController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly IWebHostEnvironment _env;

    public ResourcesController(ApplicationDbContext context, IWebHostEnvironment env)
    {
        _context = context;
        _env = env;
    }

    public IActionResult Upload()
    {
        ViewBag.Courses = _context.Courses.ToList();
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Upload(IFormFile file, int courseId)
    {
        if (file != null && file.Length > 0)
        {
            var uploads = Path.Combine(_env.WebRootPath, "uploads");
            Directory.CreateDirectory(uploads);
            var path = Path.Combine(uploads, file.FileName);

            using var stream = new FileStream(path, FileMode.Create);
            await file.CopyToAsync(stream);

            var resource = new Resource
            {
                FileName = file.FileName,
                FilePath = $"/uploads/{file.FileName}",
                CourseId = courseId
            };
            _context.Resources.Add(resource);
            await _context.SaveChangesAsync();

            return RedirectToAction("Index", "Courses");
        }
        return View();
    }
}
