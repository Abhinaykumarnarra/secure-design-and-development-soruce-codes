# XYZ Learning Academy ASP.NET Core MVC App

## Features
- Course Management (Add/Delete)
- Student Registration & Enrollment
- Resource Uploads for Courses

## Tech Stack
- ASP.NET Core MVC
- Entity Framework Core
- SQL Server

## Getting Started

1. Restore NuGet packages
2. Run EF Core migrations:
   dotnet ef migrations add InitialCreate
   dotnet ef database update

3. Run the app:
   dotnet run

## Azure Deployment
- Replace connection string in appsettings.json
- Use Visual Studio Publish wizard to Azure
